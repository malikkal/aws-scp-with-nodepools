{- define "aws-scp-with-nodepools.fullname" -}
{ include "common.names.fullname" . }
{- end -}
